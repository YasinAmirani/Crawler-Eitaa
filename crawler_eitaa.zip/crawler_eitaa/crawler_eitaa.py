import requests
from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.common.by import By
import time

url = 'https://web.eitaa.com/'

# استفاده از requests برای سایت‌های استاتیک
response = requests.get(url)
html_content = response.content
soup = BeautifulSoup(html_content, 'html.parser')

# یا استفاده از Selenium برای سایت‌های داینامیک
driver = webdriver.Firefox()
driver.get(url)

# انتظار برای بارگذاری کامل صفحه
time.sleep()

html_content = driver.page_source
soup = BeautifulSoup(html_content, 'html.parser')
driver.quit()

# استخراج لینک‌ها
links = soup.find_all('a')
for link in links:
    print(link.get('href'))
