import requests
from bs4 import BeautifulSoup
import sqlite3

# ایجاد پایگاه داده و جدول لینک‌ها
def create_db():
    conn = sqlite3.connect('crawler_data.db')
    cursor = conn.cursor()
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS links (
        id INTEGER PRIMARY KEY,
        url TEXT NOT NULL
    )
    ''')
    conn.commit()
    conn.close()

# ذخیره لینک‌ها در پایگاه داده
def save_links_to_db(links):
    conn = sqlite3.connect('crawler_data.db')
    cursor = conn.cursor()
    for link in links:
        cursor.execute('INSERT INTO links (url) VALUES (?)', (link,))
    conn.commit()
    conn.close()

# دریافت لینک‌ها از پایگاه داده
def get_links_from_db():
    conn = sqlite3.connect('crawler_data.db')
    cursor = conn.cursor()
    cursor.execute('SELECT url FROM links')
    links = cursor.fetchall()
    conn.close()
    return links

# مثال کرالر
url = 'https://web.eitaa.com/'
response = requests.get(url)
soup = BeautifulSoup(response.content, 'html.parser')
links = [link.get('href') for link in soup.find_all('a')]

# ایجاد پایگاه داده و جدول‌ها
create_db()

# ذخیره لینک‌ها در پایگاه داده
save_links_to_db(links)

# دریافت و چاپ لینک‌ها از پایگاه داده
links_from_db = get_links_from_db()
for link in links_from_db:
    print(link[0])
